import torch
from dataclasses import dataclass, field
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    BitsAndBytesConfig,
    TrainingArguments,
)
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from datasets import load_dataset
from trl import SFTTrainer
import os

@dataclass
class ModelConfig:
    # Qwen 2.5 is UNGATED - No login required
    model_name: str = "Qwen/Qwen2.5-7B-Instruct" 
    use_4bit: bool = True
    bnb_4bit_compute_dtype: str = "bfloat16" 
    bnb_4bit_quant_type: str = "nf4"
    use_nested_quant: bool = True

@dataclass
class LoRAConfig:
    lora_r: int = 128 
    lora_alpha: int = 256
    lora_dropout: float = 0.05
    target_modules: list = field(default_factory=lambda: [
        "q_proj", "k_proj", "v_proj", "o_proj",
        "gate_proj", "up_proj", "down_proj"
    ])

@dataclass
class TrainConfig:
    output_dir: str = "./cadquery_qwen_7b"
    num_train_epochs: int = 3
    per_device_train_batch_size: int = 10 # Qwen 7B is slightly smaller, can fit more
    per_device_eval_batch_size: int = 4
    gradient_accumulation_steps: int = 4 
    learning_rate: float = 2e-4
    max_grad_norm: float = 0.3
    warmup_ratio: float = 0.03
    lr_scheduler_type: str = "cosine"
    logging_steps: int = 5
    save_steps: int = 200
    eval_steps: int = 200
    save_total_limit: int = 3
    bf16: bool = True 
    optim: str = "paged_adamw_8bit"
    max_seq_length: int = 2048 
    report_to: str = "tensorboard"

def train():
    print("🚀 Initializing UNGATED High-Performance Training (Qwen 2.5)...")
    
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=ModelConfig.use_4bit,
        bnb_4bit_compute_dtype=getattr(torch, ModelConfig.bnb_4bit_compute_dtype),
        bnb_4bit_quant_type=ModelConfig.bnb_4bit_quant_type,
        bnb_4bit_use_double_quant=ModelConfig.use_nested_quant,
    )

    model = AutoModelForCausalLM.from_pretrained(
        ModelConfig.model_name,
        quantization_config=bnb_config,
        device_map="auto",
        trust_remote_code=True
    )
    
    tokenizer = AutoTokenizer.from_pretrained(ModelConfig.model_name, trust_remote_code=True)
    tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "right"

    model = prepare_model_for_kbit_training(model)
    peft_config = LoraConfig(
        r=LoRAConfig.lora_r,
        lora_alpha=LoRAConfig.lora_alpha,
        target_modules=LoRAConfig.target_modules,
        lora_dropout=LoRAConfig.lora_dropout,
        bias="none",
        task_type="CAUSAL_LM",
    )
    model = get_peft_model(model, peft_config)

    dataset = load_dataset("json", data_files={"train": "training/data/final_dataset/train.jsonl", "test": "training/data/final_dataset/validation.jsonl"})

    training_args = TrainingArguments(
        output_dir=TrainConfig.output_dir,
        num_train_epochs=TrainConfig.num_train_epochs,
        per_device_train_batch_size=TrainConfig.per_device_train_batch_size,
        gradient_accumulation_steps=TrainConfig.gradient_accumulation_steps,
        optim=TrainConfig.optim,
        save_steps=TrainConfig.save_steps,
        logging_steps=TrainConfig.logging_steps,
        learning_rate=TrainConfig.learning_rate,
        weight_decay=0.001,
        fp16=False,
        bf16=TrainConfig.bf16,
        max_grad_norm=TrainConfig.max_grad_norm,
        max_steps=-1,
        warmup_ratio=TrainConfig.warmup_ratio,
        group_by_length=True,
        lr_scheduler_type=TrainConfig.lr_scheduler_type,
        report_to=TrainConfig.report_to,
        evaluation_strategy="steps",
        eval_steps=TrainConfig.eval_steps,
    )

    trainer = SFTTrainer(
        model=model,
        train_dataset=dataset["train"],
        eval_dataset=dataset["test"],
        peft_config=peft_config,
        dataset_text_field="text",
        max_seq_length=TrainConfig.max_seq_length,
        tokenizer=tokenizer,
        args=training_args,
        packing=False,
        formatting_func=lambda x: [f"### Prompt: {p}\n### Code:\n{c}" for p, c in zip(x['prompt'], x['code'])]
    )

    print("🔥 Starting Qwen 2.5 Training...")
    trainer.train()
    trainer.model.save_pretrained(os.path.join(TrainConfig.output_dir, "final_lora"))
    print(f"✅ Training Complete! Model saved to {TrainConfig.output_dir}")

if __name__ == "__main__":
    train()
